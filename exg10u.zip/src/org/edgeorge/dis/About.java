package org.edgeorge.dis;

import android.app.Activity;
import android.os.Bundle;
//Used for About Dialog Activity
public class About extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		//Set view to About dialog
		setContentView(R.layout.about);
		
	}
	
}